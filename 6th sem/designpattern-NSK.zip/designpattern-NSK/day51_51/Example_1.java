public class Example_1
{
	// entry point : main
	public static void main(String[] args)
	{
		System.out.println("hello world");
	}
} 

