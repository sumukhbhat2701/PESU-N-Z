#include <stdio.h>
#define BEGIN {
#define END }
int main()
{
	BEGIN;
	printf("one\n");
	END;
}
// # of BEGIN == # Of  END
// at any point # Of BEGIN >= # of END
