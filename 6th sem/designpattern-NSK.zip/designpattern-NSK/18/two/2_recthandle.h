#ifndef RECTHANLDE_H
#define RECTHANLDE_H
class Rect;

class RectHandle
{
	private:
	Rect *ptr_rect;
	public:
	RectHandle(int length, int breadth);
	int find_area() const;
	void change_length(int length);
	void change_breadth(int breadth);
	~RectHandle();
};
#endif

