#ifndef PIGEON_BODY
#define PIGEON_BODY
#include "body.h"
class Pigeon_Body : public Body
{
	
};
#endif
