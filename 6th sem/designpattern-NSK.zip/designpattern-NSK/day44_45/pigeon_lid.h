#ifndef PIGEON_LID_H
#define PIGEON_LID_H
#include "lid.h"
class Pigeon_Lid : public Lid
{
};
#endif
