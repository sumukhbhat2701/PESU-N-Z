#include <iostream>
using namespace std;
#include "component.h"
#if 1
Component::~Component()
{
}
#endif
