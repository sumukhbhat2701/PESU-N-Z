#include <iostream>
using namespace std;

class A
{
	public:
	A();
	~A();
};

A::A()
{
	cout << "ctor\n";
}

A::~A()
{
	cout << "dtor\n";
}

#if 0
int main()
{
	A x; // ctor
} // dtor
#endif

#if 0
int main()
{
	A x[4]; //  4 ctor
} // 4 dtor
#endif
#if 0
int main()
{
	A x; //  ctor
	{
		A& r(x); // r refers to x; no ctor
	} // no dtor
} // dtor
#endif
#if 0
int main()
{
	{
 		A *x;  
		x = new A; // allocates memory; calls ctor
		delete x; // calls dtor; deallocates memory
	}  
}  
#endif
int main()
{
	{
 		A *x;  
		x = new A[4]; // allocates memory; calls ctor in a loop
		delete[] x; // calls dtor in loop; deallocates memory
	}  
}  


