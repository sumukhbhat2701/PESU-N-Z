#ifndef RECTHANLDE_H
#define RECTHANLDE_H
class Rect;
// class is not canonical unless all the four fundamental operators are complete
// if the default works, it is fine.
// otherwise 
//		replace the default functions
// if not required,
//		hide them 
//			declare private
//		or
//		remove them
//			ask the compiler not to provide the default fn

class RectHandle
{
	private:
	Rect *ptr_rect;
	RectHandle(const RectHandle&);
	public:
	RectHandle(int length, int breadth);
	int find_area() const;
	void change_length(int length);
	void change_breadth(int breadth);
	~RectHandle();
	RectHandle& operator=(const RectHandle&) = delete; // contextual keyword
};
#endif

