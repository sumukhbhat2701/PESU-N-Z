#include<iostream>
using namespace std;

class Ex
{
	private:
	int a;
	public:
	int b;
	void foo(){a=10;cout << a <<" ";};
	void bar() const {cout <<a <<"\n"; };
};
int main()
{
	Ex x;
	x.foo();
	x.bar();
return 0;
}
