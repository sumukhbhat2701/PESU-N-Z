#include <stdio.h>
#define A 10

int main()
{
	printf("hello world\n");
	printf("what : %d\n", A);
	printf("what : %d\n", B);
}


// using the same command(interface) for different options
//		facade

// gcc -c 1_ex.c    :  compile
// gcc 1_ex.o       : link
// gcc -E 1_ex.c    : pre-processor

// pre-processor :
//	start with #
//	#include
//	#define 
//		define a constant : #define
//							const in C
//							const constexpr in C++
//		textual; no type info


