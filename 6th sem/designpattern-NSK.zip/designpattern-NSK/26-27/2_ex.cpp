#include <iostream>
using namespace std;

class A
{
	public:
	virtual void f() const { cout << "A::f\n"; }
	virtual void g() const { cout << "A::g\n"; }
	virtual void h() const { cout << "A::h\n"; }
	
};
class B : public A
{
	public:
	virtual void f() const { cout << "B::f\n"; }
	virtual void g() const { cout << "B::g\n"; }

};
class C : public B
{
	public:
	virtual void f() const { cout << "C::f\n"; }
};
int main()
{
	A x;
	B y;
	C z;
	cout << "over\n";
}



