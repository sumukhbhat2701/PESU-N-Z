#include <iostream>
using namespace std;
#include <cstring>


class MyStr
{
	private:
	char *p_;
	public:
	MyStr(const char *p);
	~MyStr();
	//void operator=(const MyStr& rhs);
	MyStr& operator=(const MyStr& rhs);
	MyStr(const MyStr&);
	void disp();
};

// 1. alloc memory
// 2. copy str
MyStr::MyStr(const char *p)
: p_(new char[strlen(p) + 1])
{
	strcpy(p_, p);
}

MyStr::~MyStr()
{
	delete [] p_;
}

#if 0
void MyStr::operator=(const MyStr& rhs)
{
	delete [] p_;
	p_ = new char[strlen(rhs.p_) + 1];
	strcpy(p_, rhs.p_);
}
#endif

#if 0
// do nothing if self assignment
void MyStr::operator=(const MyStr& rhs)
{
	if(this != &rhs)
	{
		delete [] p_;
		p_ = new char[strlen(rhs.p_) + 1];
		strcpy(p_, rhs.p_);
	}
}
#endif
// support cascading; make = operation result in a value
MyStr& MyStr::operator=(const MyStr& rhs)
{
	if(this != &rhs)
	{
		delete [] p_;
		p_ = new char[strlen(rhs.p_) + 1];
		strcpy(p_, rhs.p_);
	}
	return *this;
}

MyStr::MyStr(const MyStr& rhs)
: p_(new char[strlen(rhs.p_) + 1])
{
	strcpy(p_, rhs.p_);
}

void MyStr::disp()
{
	cout << p_ << "\n";
}
int main()
{
#if 0
	char name[] = "pesu";
	{
	MyStr s1(name);
	s1.disp();
	name[0] = ' ';
	s1.disp();
	}
#endif
#if 0
	{
		char name2[] = "abcd";
		char name3[] = "pqrstuvw";
		MyStr s2(name2);
		MyStr s3(name3);
		s2 = s3; // assignment // s2.operator=(s3)
		s2.disp();
		s3.disp(); 
	}
	{
		char name4[] = "test";
		MyStr s4(name4);
		s4 = s4; // self assignment
		s4.disp();
	}
#endif
#if 0
	{
		MyStr x("rama");
		MyStr y("krishna");
		MyStr z("govinda");
		x = y = z;
		(x = y) = z;
		
	}
#endif
// copy ctor:
//	initializing an object with an existing object
// 	compiler by default provides a copy ctor
//		does shallow or memberwise copy
//  replace or overload to take care of resources
//  gets called in 3 cases
//		1. initialize an object with an existing object
//		2. parameter passing by value
//		3. return by value
	{
		MyStr x("India");
		MyStr y = x; // MyStr y(x); 
		x.disp();
		y.disp();
	}	
}
// valgrind : memory leak check
