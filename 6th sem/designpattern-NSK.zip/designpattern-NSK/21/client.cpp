#include <iostream>
using namespace std;
#include "mystr.h"

int main()
{
	MyStr a("hello");
	a.disp();
//	MyStr z("hello");
//	z.disp();
	{
		MyStr b(a); 
		a.disp();
		b.disp();
	}
	a.disp();
}
