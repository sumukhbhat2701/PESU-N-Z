int cube(int n)
{
	int res = n * n * n;
	return res;
}
int sq(int n)
{
	int res = n * n;
	return res;
}
