#include <iostream>
using namespace std;

class A
{
	private:
	const int a1_;
	const int a2_;
	public:
	A(int a1, int a2);
	void disp();
};

#if 0
// cannot work if the fields are const
A::A(int a1, int a2)
{
	a1_ = a1; a2_ = a2;
}
#endif
// member initialization list:
//	only in the ctor
//	required:
//		const members
//		reference members
//		base class sub object
//	order of initialization :
//		not based on the order in the member initialization list
//		1.
//		2.
//		3. order of declaration in the class
//			top to bottom
//			left to right
A::A(int a1, int a2)
: a1_(a1), a2_(a2)
// : a1_(a2_), a2_(100) // a1_ not properly initialized
//: a2_(100), a1_(a2_) // a1_ not properly initialized
{
	
}

void A::disp()
{
	cout << a1_ << "\t" << a2_ << "\n";
}

int main()
{
	A x(10, 20);
	x.disp();
}


// can we call  dtor explicitly?
//	B y; y.~B();
// if a dtor can be called explicitly, does the object die?
// if a dtor can be called explicitly, if the  object does not die, is the dtor
//	called when the object does die?
// can we call the ctor explicitly?
//	Y.B();



