
#include<iostream>
using namespace std;
class B
{
	private:
		int x_;
	public:
		B(int x);
		~B();
};
B::B(int x)
:x_(x)
{
	cout << "ctor\n";
}
B::~B()
{
	cout << "dtor\n" ;
}
int main()
{
	B y(10);
	//y.~B();
	return 0;
}

