#include<iostream>
using namespace std;
int& f2(int& x)
{
	x = x+10;
	return x;
}
int main()
{
	int a = 10,b;
	cout << a <<" ";
	f2(a) = 20;
	cout << a << " ";
	cout << b << "\n";
	return 0;
}
