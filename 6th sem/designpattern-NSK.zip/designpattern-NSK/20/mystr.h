#ifndef MYSTR_H
#define MYSTR_H
class MyStr
{
};

#endif

