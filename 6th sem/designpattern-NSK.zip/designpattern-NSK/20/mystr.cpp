#include <iostream>
using namespace std;
#include "mystr.h"
