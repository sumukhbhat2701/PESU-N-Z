#include <iostream>
using namespace std;
#include "mystr.h"

int main()
{
	MyStr a("xxxx");
	MyStr b("yyyy");
	MyStr c("xxxx");
}

