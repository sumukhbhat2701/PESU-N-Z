void foo();

