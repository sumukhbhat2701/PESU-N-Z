#include <stdio.h>
#include "2_foo.h"
void foo()
{
	printf("foo called\n");
}
