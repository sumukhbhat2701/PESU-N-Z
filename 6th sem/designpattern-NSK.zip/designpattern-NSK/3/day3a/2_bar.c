#include <stdio.h>
#include "2_bar.h"
void bar()
{
	printf("bar called\n");
}
